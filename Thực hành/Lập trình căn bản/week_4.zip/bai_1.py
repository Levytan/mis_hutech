def read_num(num):
    d = {0: 'không', 1: 'một', 2: 'hai',
         3: 'ba', 4: 'bốn', 5: 'năm',
         6: 'sáu', 7: 'bảy',
         8: 'tám', 9: 'chín'}
    a = num % 10 # số hàng đơn vị
    b = (num // 10) % 10 # số hàng chục
    c = num // 100 # số hàng trăm
    s = f'{d[c]} trăm {d[b]} mươi {d[a]}'
    
    # thay đổi cách dọc cho các số nhỏ hơn 100
    s = s.replace('không trăm ', '')
    if c > 0:
        # các số có dạng c0a
        s = s.replace('không mươi', 'linh')
    else:
        # các số nhỏ hơn 10
        s = s.replace('không mươi ', '')
    # các số có dạng cb1
    s = s.replace('mươi một', 'mươi mốt')
    # các số có dạng cb5
    s = s.replace('mươi năm', 'mươi lăm')
    # các số có dạng c1a
    s = s.replace('một mươi', 'mười')
    return s

# kiểm tra hàm
print(read_num(4))
print(read_num(41))
print(read_num(56))
print(read_num(105))
print(read_num(301))
print(read_num(361))
print(read_num(315))
print(read_num(555))
print(read_num(678))