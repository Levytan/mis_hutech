
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1001, CAST(N'2012-06-08' AS Date), N'POL', N'GRE', 4)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1002, CAST(N'2012-06-08' AS Date), N'RUS', N'CZE', 8)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1003, CAST(N'2012-06-12' AS Date), N'GRE', N'CZE', 8)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1004, CAST(N'2012-06-12' AS Date), N'POL', N'RUS', 4)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1005, CAST(N'2012-06-16' AS Date), N'CZE', N'POL', 8)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1006, CAST(N'2012-06-16' AS Date), N'GRE', N'RUS', 4)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1007, CAST(N'2012-06-09' AS Date), N'NED', N'DEN', 3)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1008, CAST(N'2012-06-09' AS Date), N'GER', N'POR', 1)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1009, CAST(N'2012-06-13' AS Date), N'DEN', N'POR', 1)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1010, CAST(N'2012-06-13' AS Date), N'NED', N'GER', 3)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1011, CAST(N'2012-06-17' AS Date), N'POR', N'NED', 3)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1012, CAST(N'2012-06-17' AS Date), N'DEN', N'GER', 1)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1013, CAST(N'2012-06-10' AS Date), N'ESP', N'ITA', 6)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1014, CAST(N'2012-06-10' AS Date), N'IRL', N'CRO', 7)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1015, CAST(N'2012-06-14' AS Date), N'ITA', N'CRO', 7)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1016, CAST(N'2012-06-14' AS Date), N'ESP', N'IRL', 6)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1017, CAST(N'2012-06-18' AS Date), N'CRO', N'ESP', 6)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1018, CAST(N'2012-06-18' AS Date), N'ITA', N'IRL', 7)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1019, CAST(N'2012-06-11' AS Date), N'FRA', N'ENG', 2)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1020, CAST(N'2012-06-11' AS Date), N'UKR', N'SWE', 5)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1021, CAST(N'2012-06-15' AS Date), N'UKR', N'FRA', 2)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1022, CAST(N'2012-06-15' AS Date), N'SWE', N'ENG', 5)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1023, CAST(N'2012-06-19' AS Date), N'ENG', N'UKR', 2)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1024, CAST(N'2012-06-19' AS Date), N'SWE', N'FRA', 5)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1025, CAST(N'2012-06-21' AS Date), N'CZE', N'POR', 4)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1026, CAST(N'2012-06-22' AS Date), N'GER', N'GRE', 6)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1027, CAST(N'2012-06-23' AS Date), N'ESP', N'FRA', 2)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1028, CAST(N'2012-06-24' AS Date), N'ENG', N'ITA', 5)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1029, CAST(N'2012-06-27' AS Date), N'POR', N'ESP', 2)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1030, CAST(N'2012-06-28' AS Date), N'GER', N'ITA', 4)
GO
INSERT [dbo].[games] ([id], [date], [home_team_id], [away_team_id], [stadium_id]) VALUES (1031, CAST(N'2012-07-01' AS Date), N'ESP', N'ITA', 5)
GO
SET IDENTITY_INSERT [dbo].[goals] ON 
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (1, 1001, N'POL', N'Robert Lewandowski', 17)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (2, 1001, N'GRE', N'Dimitris Salpingidis', 51)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (3, 1002, N'RUS', N'Alan Dzagoev', 15)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (4, 1002, N'RUS', N'Alan Dzagoev', 79)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (5, 1002, N'RUS', N'Roman Shirokov', 24)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (6, 1002, N'RUS', N'Roman Pavlyuchenko', 82)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (7, 1002, N'CZE', N'Václav Pilar', 52)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (8, 1003, N'GRE', N'Theofanis Gekas', 53)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (9, 1003, N'CZE', N'Petr Jirácek', 3)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (10, 1003, N'CZE', N'Václav Pilar', 6)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (11, 1004, N'POL', N'Jakub Blaszczykowski', 57)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (12, 1004, N'RUS', N'Alan Dzagoev', 37)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (13, 1005, N'CZE', N'Petr Jirácek', 72)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (14, 1006, N'GRE', N'Giorgos Karagounis', 45)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (15, 1007, N'DEN', N'Michael Krohn-Dehli', 24)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (16, 1008, N'GER', N'Mario Gómez', 72)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (17, 1009, N'DEN', N'Nicklas Bendtner', 41)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (18, 1009, N'DEN', N'Nicklas Bendtner', 80)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (19, 1009, N'POR', N'Pepe (footballer born 1983)', 24)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (20, 1009, N'POR', N'Hélder Postiga', 36)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (21, 1009, N'POR', N'Silvestre Varela', 87)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (22, 1010, N'NED', N'Robin van Persie', 73)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (23, 1010, N'GER', N'Mario Gómez', 24)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (24, 1010, N'GER', N'Mario Gómez', 38)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (25, 1011, N'POR', N'Cristiano Ronaldo', 28)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (26, 1011, N'POR', N'Cristiano Ronaldo', 74)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (27, 1011, N'NED', N'Rafael van der Vaart', 11)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (28, 1012, N'DEN', N'Michael Krohn-Dehli', 24)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (29, 1012, N'GER', N'Lukas Podolski', 19)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (30, 1012, N'GER', N'Lars Bender', 80)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (31, 1013, N'ESP', N'Cesc Fàbregas', 64)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (32, 1013, N'ITA', N'Antonio Di Natale', 61)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (33, 1014, N'IRL', N'Sean St Ledger', 19)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (34, 1014, N'CRO', N'Mario Mandžukic', 3)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (35, 1014, N'CRO', N'Mario Mandžukic', 49)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (36, 1014, N'CRO', N'Nikica Jelavic', 43)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (37, 1015, N'ITA', N'Andrea Pirlo', 39)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (38, 1015, N'CRO', N'Mario Mandžukic', 72)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (39, 1016, N'ESP', N'Fernando Torres', 4)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (40, 1016, N'ESP', N'Fernando Torres', 70)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (41, 1016, N'ESP', N'David Silva', 49)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (42, 1016, N'ESP', N'Cesc Fàbregas', 83)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (43, 1017, N'ESP', N'Jesús Navas', 88)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (44, 1018, N'ITA', N'Antonio Cassano', 35)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (45, 1018, N'ITA', N'Mario Balotelli', 90)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (46, 1019, N'FRA', N'Samir Nasri', 39)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (47, 1019, N'ENG', N'Joleon Lescott', 30)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (48, 1020, N'UKR', N'Andriy Shevchenko', 55)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (49, 1020, N'UKR', N'Andriy Shevchenko', 62)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (50, 1020, N'SWE', N'Zlatan Ibrahimovic', 52)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (51, 1021, N'FRA', N'Jérémy Ménez', 53)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (52, 1021, N'FRA', N'Yohan Cabaye', 56)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (53, 1022, N'SWE', N'Glen Johnson (English footballer)', 49)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (54, 1022, N'SWE', N'Olof Mellberg', 59)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (55, 1022, N'ENG', N'Andy Carroll', 23)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (56, 1022, N'ENG', N'Theo Walcott', 64)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (57, 1022, N'ENG', N'Danny Welbeck', 78)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (58, 1023, N'ENG', N'Wayne Rooney', 48)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (59, 1024, N'SWE', N'Zlatan Ibrahimovic', 54)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (60, 1024, N'SWE', N'Sebastian Larsson', 90)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (61, 1025, N'POR', N'Cristiano Ronaldo', 79)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (62, 1026, N'GER', N'Philipp Lahm', 39)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (63, 1026, N'GER', N'Sami Khedira', 61)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (64, 1026, N'GER', N'Miroslav Klose', 68)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (65, 1026, N'GER', N'Marco Reus', 74)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (66, 1026, N'GRE', N'Georgios Samaras', 55)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (67, 1026, N'GRE', N'Dimitris Salpingidis', 89)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (68, 1027, N'ESP', N'Xabi Alonso', 19)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (69, 1027, N'ESP', N'Xabi Alonso', 90)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (70, 1030, N'GER', N'Mesut Özil', 90)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (71, 1030, N'ITA', N'Mario Balotelli', 20)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (72, 1030, N'ITA', N'Mario Balotelli', 36)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (73, 1031, N'ESP', N'David Silva', 14)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (74, 1031, N'ESP', N'Jordi Alba', 41)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (75, 1031, N'ESP', N'Fernando Torres', 84)
GO
INSERT [dbo].[goals] ([id], [game_id], [team_id], [player], [goal_time]) VALUES (76, 1031, N'ESP', N'Juan Mata', 88)
GO
SET IDENTITY_INSERT [dbo].[goals] OFF
GO
