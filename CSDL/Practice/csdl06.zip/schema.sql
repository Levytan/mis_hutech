CREATE DATABASE [csdl06]
GO

USE [csdl06]
GO
/****** Object:  Table [dbo].[booking]    Script Date: 9/3/2020 10:55:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[booking](
	[booking_id] [int] NOT NULL,
	[booking_date] [date] NULL,
	[room_no] [int] NULL,
	[guest_id] [int] NOT NULL,
	[occupants] [int] NOT NULL,
	[room_type_requested] [varchar](6) NULL,
	[nights] [int] NOT NULL,
	[arrival_time] [varchar](5) NULL,
PRIMARY KEY CLUSTERED 
(
	[booking_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[guest]    Script Date: 9/3/2020 10:55:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[guest](
	[id] [int] NOT NULL,
	[first_name] [varchar](50) NULL,
	[last_name] [varchar](50) NULL,
	[address] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[rate]    Script Date: 9/3/2020 10:55:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[rate](
	[room_type] [varchar](6) NOT NULL,
	[occupancy] [int] NOT NULL,
	[amount] [decimal](10, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[room_type] ASC,
	[occupancy] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[room]    Script Date: 9/3/2020 10:55:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[room](
	[id] [int] NOT NULL,
	[room_type] [varchar](6) NULL,
	[max_occupancy] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[room_type]    Script Date: 9/3/2020 10:55:18 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[room_type](
	[id] [varchar](6) NOT NULL,
	[description] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[booking] ADD  DEFAULT (NULL) FOR [booking_date]
GO
ALTER TABLE [dbo].[booking] ADD  DEFAULT (NULL) FOR [room_no]
GO
ALTER TABLE [dbo].[booking] ADD  DEFAULT ('1') FOR [occupants]
GO
ALTER TABLE [dbo].[booking] ADD  DEFAULT (NULL) FOR [room_type_requested]
GO
ALTER TABLE [dbo].[booking] ADD  DEFAULT ('1') FOR [nights]
GO
ALTER TABLE [dbo].[booking] ADD  DEFAULT (NULL) FOR [arrival_time]
GO
ALTER TABLE [dbo].[guest] ADD  DEFAULT (NULL) FOR [first_name]
GO
ALTER TABLE [dbo].[guest] ADD  DEFAULT (NULL) FOR [last_name]
GO
ALTER TABLE [dbo].[guest] ADD  DEFAULT (NULL) FOR [address]
GO
ALTER TABLE [dbo].[rate] ADD  DEFAULT ('') FOR [room_type]
GO
ALTER TABLE [dbo].[rate] ADD  DEFAULT ('0') FOR [occupancy]
GO
ALTER TABLE [dbo].[rate] ADD  DEFAULT (NULL) FOR [amount]
GO
ALTER TABLE [dbo].[room] ADD  DEFAULT (NULL) FOR [room_type]
GO
ALTER TABLE [dbo].[room] ADD  DEFAULT (NULL) FOR [max_occupancy]
GO
ALTER TABLE [dbo].[room_type] ADD  DEFAULT (NULL) FOR [description]
GO
ALTER TABLE [dbo].[booking]  WITH CHECK ADD  CONSTRAINT [booking_ibfk_1] FOREIGN KEY([room_no])
REFERENCES [dbo].[room] ([id])
GO
ALTER TABLE [dbo].[booking] CHECK CONSTRAINT [booking_ibfk_1]
GO
ALTER TABLE [dbo].[booking]  WITH CHECK ADD  CONSTRAINT [booking_ibfk_2] FOREIGN KEY([guest_id])
REFERENCES [dbo].[guest] ([id])
GO
ALTER TABLE [dbo].[booking] CHECK CONSTRAINT [booking_ibfk_2]
GO
ALTER TABLE [dbo].[booking]  WITH CHECK ADD  CONSTRAINT [booking_ibfk_3] FOREIGN KEY([room_type_requested])
REFERENCES [dbo].[room_type] ([id])
GO
ALTER TABLE [dbo].[booking] CHECK CONSTRAINT [booking_ibfk_3]
GO
ALTER TABLE [dbo].[booking]  WITH CHECK ADD  CONSTRAINT [booking_ibfk_4] FOREIGN KEY([room_type_requested], [occupants])
REFERENCES [dbo].[rate] ([room_type], [occupancy])
GO
ALTER TABLE [dbo].[booking] CHECK CONSTRAINT [booking_ibfk_4]
GO
ALTER TABLE [dbo].[rate]  WITH CHECK ADD  CONSTRAINT [rate_ibfk_1] FOREIGN KEY([room_type])
REFERENCES [dbo].[room_type] ([id])
GO
ALTER TABLE [dbo].[rate] CHECK CONSTRAINT [rate_ibfk_1]
GO
ALTER TABLE [dbo].[room]  WITH CHECK ADD  CONSTRAINT [room_ibfk_1] FOREIGN KEY([room_type])
REFERENCES [dbo].[room_type] ([id])
GO
ALTER TABLE [dbo].[room] CHECK CONSTRAINT [room_ibfk_1]
GO
